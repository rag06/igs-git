<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>
	Global Access Pharmacy
</title>
<meta name="viewport" content="width=device-width, initial-scale=1" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="keywords" content="The Pharma USA" />
<link href="<?php echo base_url(); ?>html/web/MCSS/Copies.css" rel="stylesheet" type="text/css" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- Custom Theme files -->
    <link href="<?php echo base_url(); ?>html/web/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo base_url(); ?>html/web/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo base_url(); ?>html/web/css/menu.css" rel="stylesheet" type="text/css" media="all" />
    <!-- menu style -->
    <link href="<?php echo base_url(); ?>html/web/css/ken-burns.css" rel="stylesheet" type="text/css" media="all" />
    <!-- banner slider -->
    <link href="<?php echo base_url(); ?>html/web/css/animate.min.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo base_url(); ?>html/web/css/owl.carousel.css" rel="stylesheet" type="text/css" media="all" />
    <!-- carousel slider -->
    <!-- //Custom Theme files -->
    <!-- font-awesome icons -->
    <link href="<?php echo base_url(); ?>html/web/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>html/web/css/comment.css" rel="stylesheet" />
    <!-- //font-awesome icons -->
    <!-- js -->
    <script src="<?php echo base_url(); ?>html/web/js/jquery-2.2.3.min.js" type="text/javascript"></script>
    <!-- //js -->
    <!-- web-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Lovers+Quarrel" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Offside" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet" type="text/css" />
    <!-- web-fonts -->
    <script src="<?php echo base_url(); ?>html/web/js/owl.carousel.js"></script>
    <script>
        $(document).ready(function () {
            $("#owl-demo").owlCarousel({
                autoPlay: 3000, //Set AutoPlay to 3 seconds 
                items: 4,
                itemsDesktop: [640, 5],
                itemsDesktopSmall: [480, 2],
                navigation: true

            });

            $('p').css('text-align', 'justify');

            $('h3').css('margin-top', '1%');

        }); 
    </script>
    <script src="<?php echo base_url(); ?>html/web/js/jquery-scrolltofixed-min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {

            // Dock the header to the top of the window when scrolled past the banner. This is the default behaviour.

            $('.header-two').scrollToFixed();
            // previous summary up the page.

            var summaries = $('.summary');
            summaries.each(function (i) {
                var summary = $(summaries[i]);
                var next = summaries[i + 1];

                summary.scrollToFixed({
                    marginTop: $('.header-two').outerHeight(true) + 10,
                    zIndex: 999
                });
            });
        });
    </script>
    <!-- start-smooth-scrolling -->
    <script type="text/javascript" src="<?php echo base_url(); ?>html/web/js/move-top.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>html/web/js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({ scrollTop: $(this.hash).offset().top }, 1000);
            });
        });
    </script>
    <!-- //end-smooth-scrolling -->
    <!-- smooth-scrolling-of-move-up -->
    <script type="text/javascript">
        $(document).ready(function () {

            var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear'
            };

            $().UItoTop({ easingType: 'easeOutQuart' });

        });
    </script>
    <!-- //smooth-scrolling-of-move-up -->
    <script src="<?php echo base_url(); ?>html/web/js/bootstrap.js" type="text/javascript"></script>
    <link href="<?php echo base_url(); ?>html/web/font-awesome/css/font-awesome-ie7.css" rel="stylesheet" type="text/css" />
 
<script>
  (function() {
    var cx = '012124690306191263242:iee2j1zxn2y';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
 
</head>
<body>
 <div>
        <div class="header">
            <div class="w3ls-header">
                <!--header-one-->
                <div class="w3ls-header-left">
                    <p>
                        <a href="javascript:void(0)">Generic Viagra - Medication For Male Impotence Treatment </a>
                    </p>
                </div>
                <div class="w3ls-header-right">
                    <ul>
                        <li class="dropdown head-dpdn"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span id="LblUser">My Account</span><span class="caret"></span></a>
                            <ul class="dropdown-menu">
								<?php if(!isset($this->session->userdata['front_logged_in']) ||empty($this->session->userdata['front_logged_in']['front_name'])){?>
                                <li ><a href="<?php echo base_url();?>login/login">Login </a></li>
                                <li><a href="<?php echo base_url();?>login/login/register">Sign Up</a></li>
                                <li><a href="<?php echo base_url();?>/shopping/cart">Cart </a></li>  
								<?php } else{ ?>                           
                                <li><a href="<?php echo base_url();?>/orders/orders">My Orders</a></li>
                               <li><a href="<?php echo base_url();?>login/login/changePassword">Change Password</a></li>
                                <li><a href="<?php echo base_url();?>/shopping/cart">Cart </a></li>  
                                <li><a href="<?php echo base_url();?>login/login/logout" id="Logout">Log Out</a></li>
								<?php }?>
                            </ul>
                        </li>
                        <!--<li class="dropdown head-dpdn">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-percent" aria-hidden="true"></i> Today's Deals<span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="#">Cash Back Offers</a></li> 
							<li><a href="#">Product Discounts</a></li>
							<li><a href="#">Special Offers</a></li> 
						</ul> 
					</li>-->
                        <li class="dropdown head-dpdn"><a href="#" class="dropdown-toggle"><i class="fa fa-mobile-phone"
                            aria-hidden="true"></i>Toll Free +1 502 209 5549</a> </li>
                        <!--<li class="dropdown head-dpdn">
						<a href="#" class="dropdown-toggle"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
					</li>-->
                    </ul>
                </div>
                <div class="clearfix">
                </div>
            </div>
            <div class="header-two">
                <div class="container">
                    <div class="header-logo">
                        <h1>
                            <a href="<?php echo base_url();?>">
                                <img src="<?php echo base_url(); ?>html/web/images/logo1.png" class="img-responsive" /></a></h1>
                    </div>
                    <div class="header-search">
                            <form class="navbar-form" role="search" name="cse" id="searchbox" action="<?php echo base_url();?>home/home/searchResults" method="get">
								<div class="input-group">
									<input name="q" id="q" type="search" placeholder="Search for a Product..." title="Search for a Product..." style="width: 290px;" />
									<div class="input-group-btn">
										<button type="submit" id="btnSearch" class="btn btn-default" aria-label="Left Align" >
											<i class="fa fa-search" aria-hidden="true"></i>
										</button>
									</div>
									
								</div>
							</form>
                    </div>
                    <div class="header-cart">
                        <div class="">
                            <a href="<?php echo base_url();?>/shopping/cart" class="btn btn-primary btn-circle btn-xl btn-circle"><i class="fa fa-cart-arrow-down"
                                aria-hidden="true"></i>
                                <span id="LblCartCount"><?php $cart = $this->cart->contents(); echo sizeOf($cart);?></span>
                            </a>
                        </div>
                        <div class="clearfix">
                        </div>
                    </div>
                    <div class="clearfix">
                    </div>
                </div>
            </div>
            <!-- //header-two -->
            <div class="header-three">
                <div class="container">
                    <div class="menu">
                        <div class="cd-dropdown-wrapper">
                            <a class="cd-dropdown-trigger" href="#0">All Categories</a>
                            <nav class="cd-dropdown"> 
							<a href="#0" class="cd-close">Close</a>
							<ul class="cd-dropdown-content"> 
								 <?php 
								
									foreach($category as $ctgrow){
										 
								 ?>
								<li class="has-children">
									<a href="#"><?php echo $ctgrow->pCtg_Name;?></a>
									<ul class="cd-secondary-dropdown is-hidden">
										<li class="go-back"><a href="#">Menu</a></li>
										<li class="has-children">
											<h4><?php echo $ctgrow->pCtg_Name;?></h4>
											<ul>
												<?php 
												$tempproduct=[];
													foreach($products['result'] as $tempproductrow){
														if($tempproductrow->product_Ctg  == $ctgrow->pCtg_ID ){
															array_push($tempproduct,$tempproductrow);
														}
													}
													if(sizeof($tempproduct)>0){
													foreach($tempproduct as $productrow){
														
														if($productrow->product_Ctg  == $ctgrow->pCtg_ID ){
														
												?>
														<li> <a href="<?php echo base_url();?>products/products/details/<?php echo $productrow->product_ID; ?>/<?php echo $productrow->product_Name; ?>" style="color:#000;"><?php echo $productrow->product_Name;?></a> </li> 
												<?php }
												}
													}else{
													?>
													 <li><img src="<?php echo base_url(); ?>html/web/comingsoon.jpg" class="img-responsive" />  </li> 
													<?php } ?>
													</ul>
										</li>
									</ul>
								</li>
									<?php } ?>
							</ul>
                              
						</nav>
                        </div>
                    </div>
                    <div class="move-text">
                        <nav class="navbar">
							<div class="navbar-header">
							  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>                        
							  </button>
							</div>
							<div class="collapse navbar-collapse" id="myNavbar">
							  <ul class="nav navbar-nav">
							  <li><a href="<?php echo base_url();?>upload/prescription">Upload Prescription</a></li>
								<li><a href="<?php echo base_url();?>about/about">About Us</a></li>
								<li><a href="<?php echo base_url();?>reviews/reviews">Reviews</a></li>
								<li><a href="<?php echo base_url();?>faq/faq">FAQ</a></li>
								<li><a href="<?php echo base_url();?>disclaimer/disclaimer">Disclaimer</a></li>
							   
								<li><a href="<?php echo base_url();?>policy/shipping"> Shipping Policy</a></li>
								
							  </ul>
							</div>
						</nav>
                    </div>
                </div>
            </div>
        </div>
        